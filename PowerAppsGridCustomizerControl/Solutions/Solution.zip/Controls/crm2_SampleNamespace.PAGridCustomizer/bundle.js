/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./PAGridCustomizer/customizers/CellEditorOverrides.tsx"
/*!**************************************************************!*\
  !*** ./PAGridCustomizer/customizers/CellEditorOverrides.tsx ***!
  \**************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   cellEditorOverrides: () => (/* binding */ cellEditorOverrides)\n/* harmony export */ });\nvar cellEditorOverrides = {\n  [\"Text\"]: (props, col) => {\n    // TODO: Add your custom cell editor overrides here\n    return null;\n  }\n};\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./PAGridCustomizer/customizers/CellEditorOverrides.tsx?\n}");

/***/ },

/***/ "./PAGridCustomizer/customizers/CellRendererOverrides.tsx"
/*!****************************************************************!*\
  !*** ./PAGridCustomizer/customizers/CellRendererOverrides.tsx ***!
  \****************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   cellRendererOverrides: () => (/* binding */ cellRendererOverrides)\n/* harmony export */ });\n/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @fluentui/react */ \"@fluentui/react\");\n/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nvar cellRendererOverrides = {\n  [\"Text\"]: (props, col) => {\n    if (col.colDefs[col.columnIndex].name === \"cr549_cms_group\" && props.formattedValue != null && props.formattedValue != \"\") {\n      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.Stack, {\n        verticalAlign: \"center\",\n        horizontalAlign: \"start\",\n        style: {\n          height: \"100%\",\n          paddingLeft: \"8px\"\n        }\n      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.Text, {\n        style: {\n          backgroundColor: \"#EBE8CE\",\n          paddingLeft: \"8px\",\n          paddingRight: \"8px\",\n          borderRadius: \"4px\"\n        }\n      }, props.formattedValue));\n    } else if (col.colDefs[col.columnIndex].name === \"cr549_cms_office\" && props.formattedValue != null && props.formattedValue != \"\") {\n      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.Stack, {\n        verticalAlign: \"center\",\n        horizontalAlign: \"start\",\n        style: {\n          height: \"100%\",\n          paddingLeft: \"8px\"\n        }\n      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.Text, {\n        style: {\n          backgroundColor: \"#E6C8DB\",\n          paddingLeft: \"8px\",\n          paddingRight: \"8px\",\n          borderRadius: \"4px\"\n        }\n      }, props.formattedValue));\n    } else if (col.colDefs[col.columnIndex].name.endsWith(\"cr549_projectnumber\") && props.formattedValue != null && props.formattedValue != \"\") {\n      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.Stack, {\n        verticalAlign: \"center\",\n        horizontalAlign: \"start\",\n        style: {\n          height: \"100%\",\n          paddingLeft: \"8px\"\n        }\n      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.Text, {\n        style: {\n          backgroundColor: \"#EBE8CE\",\n          paddingLeft: \"8px\",\n          paddingRight: \"8px\",\n          borderRadius: \"4px\"\n        }\n      }, props.formattedValue));\n    } else if (col.colDefs[col.columnIndex].name === \"cr549_acct_name\" && props.formattedValue != null && props.formattedValue != \"\") {\n      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.Stack, {\n        verticalAlign: \"center\",\n        horizontalAlign: \"start\",\n        style: {\n          height: \"100%\",\n          paddingLeft: \"8px\"\n        }\n      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.Text, {\n        style: {\n          backgroundColor: \"#EBE8CE\",\n          paddingLeft: \"8px\",\n          paddingRight: \"8px\",\n          borderRadius: \"4px\"\n        }\n      }, props.formattedValue));\n    }\n  },\n  // [\"TwoOptions\"]: (props: CellRendererProps, col) => {\n  // \tif (col.colDefs[col.columnIndex].name === \"cr549_marketplace\") {\n  // \t\treturn <Stack verticalAlign=\"center\" horizontalAlign=\"start\" style={{height: \"100%\", paddingLeft: \"8px\"}}>\n  // \t\t\t<Toggle\n  //                 style={{marginLeft: \"5px\", border: \"none\"}}\n  // \t\t\t          checked={props.value == 1}\n  // \t\t\t          inlineLabel label= {props.value == 1 ? \"Yes\" : \"No\"}\n  // \t\t\t          styles={{\n  //                   label: { order: 1 },\n  //                   root: {\n  //                     selectors: {\n  //                       \"&:hover .ms-Toggle-thumb\": {\n  //                         backgroundColor: props.value == 1 ? \"#C6F6DB\" : \"#ffffff !important\"\n  //                       }\n  //                     }\n  //                   },\n  //                   thumb: {\n  //                     backgroundColor: props.value == 1 ? \"#C6F6DB\" : \"#ffffff\",\n  //                     color: \"red\",\n  //                     height: 20, width: 20, padding: 1,\n  //                     selectors: {\n  //                       \":hover\": {\n  //                         backgroundColor: props.value == 1 ? \"#C6F6DB\" : \"#ffffff\"   \n  //                       },\n  //                       '[aria-checked=\"true\"] &': {\n  //                         backgroundColor: props.value == 1 ? \"#C6F6DB\" : \"#ffffff\"\n  //                       },\n  //                       '[aria-checked=\"true\"]:hover &': {\n  //                         backgroundColor: props.value == 1 ? \"#C6F6DB\" : \"#ffffff\"   \n  //                       }\n  //                     }\n  //                   },\n  //                   container: { display: 'flex', flexDirection: 'row-reverse' },\n  //                   pill: {\n  //                     backgroundColor: props.value == 1 ? \"#7BEBAC\" : \"rgb(211,211,211)\",\n  //                     height: 24, padding: 0, width: 44, borderRadius: 12,\n  //                     selectors: {\n  //                       ':hover': { backgroundColor: props.value == 1 ? \"#7BEBAC\" : \"#e6e6e6\" }\n  //                     },\n  //                     border: \"1px solid\",\n  //                     alignItems: \"center\"\n  //                   }\n  //                 }}\n  //               />\n  // \t\t</Stack>;\n  // \t}\n  // }\n  [\"TwoOptions\"]: (props, col) => {\n    if (col.colDefs[col.columnIndex].name === \"cr549_marketplace\") {\n      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.Stack, {\n        verticalAlign: \"center\",\n        horizontalAlign: \"center\",\n        style: {\n          height: \"100%\",\n          paddingLeft: \"8px\"\n        }\n      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.Text, {\n        style: {\n          color: props.value == 1 ? \"#12890E\" : \"#E31C3D\"\n        }\n      }, props.value == 1 ? \"Yes\" : \"No\"));\n    }\n    if (col.colDefs[col.columnIndex].name == \"cr549_decom_flag\" && props.formattedValue != null && props.formattedValue != \"\") {\n      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.Stack, {\n        verticalAlign: \"center\",\n        horizontalAlign: \"start\",\n        style: {\n          height: \"100%\",\n          paddingLeft: \"8px\"\n        }\n      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.Text, {\n        style: {\n          color: props.value == 0 ? \"#12890E\" : \"#E31C3D\"\n        }\n      }, props.formattedValue));\n    }\n  }\n};\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./PAGridCustomizer/customizers/CellRendererOverrides.tsx?\n}");

/***/ },

/***/ "./PAGridCustomizer/index.ts"
/*!***********************************!*\
  !*** ./PAGridCustomizer/index.ts ***!
  \***********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   PAGridCustomizer: () => (/* binding */ PAGridCustomizer)\n/* harmony export */ });\n/* harmony import */ var _customizers_CellRendererOverrides__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./customizers/CellRendererOverrides */ \"./PAGridCustomizer/customizers/CellRendererOverrides.tsx\");\n/* harmony import */ var _customizers_CellEditorOverrides__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./customizers/CellEditorOverrides */ \"./PAGridCustomizer/customizers/CellEditorOverrides.tsx\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nclass PAGridCustomizer {\n  /**\r\n   * Empty constructor.\r\n   */\n  constructor() {\n    // Empty\n  }\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   */\n  init(context, notifyOutputChanged, state) {\n    var eventName = context.parameters.EventName.raw;\n    if (eventName) {\n      var paOneGridCustomizer = {\n        cellRendererOverrides: _customizers_CellRendererOverrides__WEBPACK_IMPORTED_MODULE_0__.cellRendererOverrides,\n        cellEditorOverrides: _customizers_CellEditorOverrides__WEBPACK_IMPORTED_MODULE_1__.cellEditorOverrides\n      };\n      // eslint-disable-next-line @typescript-eslint/no-explicit-any,@typescript-eslint/no-unsafe-call,@typescript-eslint/no-unsafe-member-access\n      context.factory.fireEvent(eventName, paOneGridCustomizer);\n    }\n  }\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   * @returns ReactElement root react element for the control\r\n   */\n  updateView(context) {\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2__.createElement(react__WEBPACK_IMPORTED_MODULE_2__.Fragment);\n  }\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n  getOutputs() {\n    return {};\n  }\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n  destroy() {\n    // Add code to cleanup control if necessary\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./PAGridCustomizer/index.ts?\n}");

/***/ },

/***/ "@fluentui/react"
/*!**************************************!*\
  !*** external "FluentUIReactv81211" ***!
  \**************************************/
(module) {

module.exports = FluentUIReactv81211;

/***/ },

/***/ "react"
/*!***************************!*\
  !*** external "Reactv16" ***!
  \***************************/
(module) {

module.exports = Reactv16;

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Check if module exists (development only)
/******/ 		if (__webpack_modules__[moduleId] === undefined) {
/******/ 			var e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./PAGridCustomizer/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('SampleNamespace.PAGridCustomizer', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.PAGridCustomizer);
} else {
	var SampleNamespace = SampleNamespace || {};
	SampleNamespace.PAGridCustomizer = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.PAGridCustomizer;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}