/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./AccountsGridCustomizer/customizers/CellCustomRender.tsx"
/*!*****************************************************************!*\
  !*** ./AccountsGridCustomizer/customizers/CellCustomRender.tsx ***!
  \*****************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   CellCustomRender: () => (/* binding */ CellCustomRender)\n/* harmony export */ });\n/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @fluentui/react */ \"@fluentui/react\");\n/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nvar CellCustomRender = {\n  [\"Text\"]: (props, col) => {\n    if (col.colDefs[col.columnIndex].name === \"cr549_acct_name\" && props.formattedValue != null && props.formattedValue != \"\") {\n      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.Stack, {\n        verticalAlign: \"center\",\n        horizontalAlign: \"start\",\n        style: {\n          height: \"100%\",\n          paddingLeft: \"8px\"\n        }\n      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.Text, {\n        style: {\n          backgroundColor: \"#EBE8CE\",\n          paddingLeft: \"8px\",\n          paddingRight: \"8px\",\n          borderRadius: \"4px\"\n        }\n      }, props.formattedValue));\n    } else if (col.colDefs[col.columnIndex].name.includes(\"cr549_cms_office\") && props.formattedValue != null && props.formattedValue != \"\") {\n      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.Stack, {\n        verticalAlign: \"center\",\n        horizontalAlign: \"start\",\n        style: {\n          height: \"100%\",\n          paddingLeft: \"8px\"\n        }\n      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.Text, {\n        style: {\n          backgroundColor: \"#E6C8DB\",\n          paddingLeft: \"8px\",\n          paddingRight: \"8px\",\n          borderRadius: \"4px\"\n        }\n      }, props.formattedValue));\n    } else if (col.colDefs[col.columnIndex].name.endsWith(\"cr549_projectnumber\") && props.formattedValue != null && props.formattedValue != \"\") {\n      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.Stack, {\n        verticalAlign: \"center\",\n        horizontalAlign: \"start\",\n        style: {\n          height: \"100%\",\n          paddingLeft: \"8px\"\n        }\n      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.Text, {\n        style: {\n          backgroundColor: \"#EBE8CE\",\n          paddingLeft: \"8px\",\n          paddingRight: \"8px\",\n          borderRadius: \"4px\"\n        }\n      }, props.formattedValue));\n    }\n  },\n  [\"TwoOptions\"]: (props, col) => {\n    if (col.colDefs[col.columnIndex].name.includes(\"cr549_marketplace\")) {\n      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.Stack, {\n        verticalAlign: \"center\",\n        horizontalAlign: \"start\",\n        style: {\n          height: \"100%\",\n          paddingLeft: \"8px\"\n        }\n      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.Text, {\n        style: {\n          color: props.value == 1 ? \"#12890E\" : \"#E31C3D\"\n        }\n      }, props.value == 1 ? \"Yes\" : \"No\"));\n    } else if (col.colDefs[col.columnIndex].name == \"cr549_decom_flag\" && props.formattedValue != null && props.formattedValue != \"\") {\n      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.Stack, {\n        verticalAlign: \"center\",\n        horizontalAlign: \"start\",\n        style: {\n          height: \"100%\",\n          paddingLeft: \"8px\"\n        }\n      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.Text, {\n        style: {\n          color: props.value == 0 ? \"#12890E\" : \"#E31C3D\"\n        }\n      }, props.formattedValue));\n    }\n  }\n};\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./AccountsGridCustomizer/customizers/CellCustomRender.tsx?\n}");

/***/ },

/***/ "./AccountsGridCustomizer/index.ts"
/*!*****************************************!*\
  !*** ./AccountsGridCustomizer/index.ts ***!
  \*****************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   AccountsGridCustomizer: () => (/* binding */ AccountsGridCustomizer)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _customizers_CellCustomRender__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./customizers/CellCustomRender */ \"./AccountsGridCustomizer/customizers/CellCustomRender.tsx\");\n\n\nclass AccountsGridCustomizer {\n  /**\r\n   * Empty constructor.\r\n   */\n  constructor() {\n    // Empty\n  }\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\r\n   */\n  init(context, notifyOutputChanged, state) {\n    var eventName = context.parameters.EventName.raw;\n    if (eventName) {\n      var paOneGridCustomizer = {\n        cellRendererOverrides: _customizers_CellCustomRender__WEBPACK_IMPORTED_MODULE_1__.CellCustomRender\n      };\n      // eslint-disable-next-line @typescript-eslint/no-explicit-any,@typescript-eslint/no-unsafe-call,@typescript-eslint/no-unsafe-member-access\n      context.factory.fireEvent(eventName, paOneGridCustomizer);\n    }\n  }\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   * @returns ReactElement root react element for the control\r\n   */\n  updateView(context) {\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment);\n  }\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n  getOutputs() {\n    return {};\n  }\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n  destroy() {\n    // Add code to cleanup control if necessary\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./AccountsGridCustomizer/index.ts?\n}");

/***/ },

/***/ "@fluentui/react"
/*!**************************************!*\
  !*** external "FluentUIReactv81211" ***!
  \**************************************/
(module) {

module.exports = FluentUIReactv81211;

/***/ },

/***/ "react"
/*!***************************!*\
  !*** external "Reactv16" ***!
  \***************************/
(module) {

module.exports = Reactv16;

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Check if module exists (development only)
/******/ 		if (__webpack_modules__[moduleId] === undefined) {
/******/ 			var e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./AccountsGridCustomizer/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('PCFCONTROLS.AccountsGridCustomizer', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.AccountsGridCustomizer);
} else {
	var PCFCONTROLS = PCFCONTROLS || {};
	PCFCONTROLS.AccountsGridCustomizer = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.AccountsGridCustomizer;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}